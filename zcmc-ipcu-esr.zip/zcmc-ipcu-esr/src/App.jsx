import React from 'react'
import IpccPoster from './components/IpccPoster'

export default function App(){ 
  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-gradient-to-r from-sky-800 to-teal-400 text-white shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center gap-4">
          <div className="flex items-center gap-3">
            <img src="/zcmc-logo.png" alt="ZCMC Logo" className="h-12 w-12 object-contain rounded-md bg-white p-1" onError={(e)=>{e.currentTarget.style.display='none'}} />
            <div>
              <div className="font-semibold text-lg">Zamboanga City Medical Center</div>
              <div className="text-sm opacity-90">Infection Prevention and Control Unit – Easy Standardized Reference (IPCU-ESR)</div>
            </div>
          </div>
          <div className="ml-auto text-xs opacity-90">Interactive IPCC Poster — Staff Reference</div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-6">
        <IpccPoster />
      </main>
    </div>
  )
}
