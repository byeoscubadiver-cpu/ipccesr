import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Hand, Droplet, Zap, ShieldCheck, ShieldAlert, Download, Printer, Info } from 'lucide-react'

export default function IpccPoster(){
  const [active, setActive] = useState('hand-hygiene')
  const [openModal, setOpenModal] = useState(false)

  const sections = [
    { id:'hand-hygiene', title:'Hand Hygiene', icon:'Hand', color:'bg-sky-50', bullets:[
      'Why: Prevent healthcare-associated infections',
      'When: Before & after patient contact, before aseptic tasks, after body fluids, after touching surroundings',
      'How: Wet → Soap → Rub 20–30s → Rinse → Dry (or use ABHR if hands not visibly soiled)',
      'Do: Keep nails short, use moisturizer',
      "Don't: Wear rings or nail polish"]},
    { id:'clean-disinfect', title:'Cleaning & Disinfection', icon:'Droplet', color:'bg-emerald-50', bullets:[
      'Why: Eliminate infectious agents on surfaces & equipment',
      'Routine: Clean least → most contaminated areas',
      'Use: Appropriate disinfectant; 0.5% sodium hypochlorite for blood spills',
      'Steps: Wear PPE → Remove visible dirt → Apply disinfectant with contact time → Rinse/dry',
      'Do: Use color-coded materials; avoid reusing mop water']},
    { id:'needlestick', title:'Preventing Needlestick Injury', icon:'Zap', color:'bg-amber-50', bullets:[
      'Why: Prevent bloodborne pathogen transmission (HIV, HBV, HCV)',
      'Key: Do NOT recap needles; use safety devices',
      'Dispose: Immediately into puncture-proof sharps containers',
      'If exposure: Wash, report, start PEP as indicated']},
    { id:'ppe', title:'Personal Protective Equipment (PPE)', icon:'ShieldCheck', color:'bg-indigo-50', bullets:[
      'Why: Protect staff & patients from exposure',
      'Donning: Gown → Mask/Respirator → Goggles/Shield → Gloves',
      'Doffing: Gloves → Goggles/Shield → Gown → Mask/Respirator',
      'Do: Hand hygiene before & after PPE; check fit for respirators']},
    { id:'precautions', title:'Standard & Transmission-Based Precautions', icon:'ShieldAlert', color:'bg-rose-50', bullets:[
      'Standard: Apply to all patients (hand hygiene, PPE, respiratory hygiene, injection safety)',
      'Contact: Gloves & gown (e.g., MRSA, C. difficile)',
      'Droplet: Surgical mask (e.g., influenza)',
      'Airborne: N95 + negative-pressure room (e.g., TB, measles)',
      'Combine standard + transmission-based for full protection']}
  ]

  function renderIcon(id){
    switch(id){
      case 'Hand': return <Hand className="h-6 w-6" />
      case 'Droplet': return <Droplet className="h-6 w-6" />
      case 'Zap': return <Zap className="h-6 w-6" />
      case 'ShieldCheck': return <ShieldCheck className="h-6 w-6" />
      case 'ShieldAlert': return <ShieldAlert className="h-6 w-6" />
      default: return <Info className="h-6 w-6" />
    }
  }

  function copyToClipboard(text){
    if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText){
      navigator.clipboard.writeText(text).then(()=>alert('Copied summary to clipboard')).catch(()=>alert('Unable to copy'))
    } else {
      try {
        const textarea = document.createElement('textarea')
        textarea.value = text
        document.body.appendChild(textarea)
        textarea.select()
        document.execCommand('copy')
        document.body.removeChild(textarea)
        alert('Copied summary to clipboard (fallback)')
      } catch(e){ alert('Copy not supported in this environment. Please copy manually.') }
    }
  }

  function exportAsPdf(){ if (typeof window !== 'undefined' && typeof window.print === 'function') window.print() }

  return (
    <div className="min-h-screen bg-white text-slate-800 p-6 lg:p-12 rounded-md shadow-sm">
      <div className="max-w-6xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl lg:text-3xl font-semibold">ZCMC IPCC — Easy Standardized Reference</h1>
            <p className="text-sm text-slate-500">Quick guide for clinical and non-clinical staff</p>
          </div>

          <div className="flex items-center gap-3">
            <button onClick={()=>setOpenModal(true)} className="flex items-center gap-2 px-3 py-2 border rounded-md text-sm bg-white hover:bg-teal-50">
              <Info className="h-4 w-4 text-teal-600" /> Quick Tips
            </button>

            <button onClick={()=>exportAsPdf()} className="flex items-center gap-2 px-3 py-2 border rounded-md text-sm bg-white hover:bg-teal-50">
              <Printer className="h-4 w-4 text-teal-600" /> Print / Save PDF
            </button>

            <button onClick={()=>copyToClipboard('ZCMC IPCC reference — open the interactive poster on the staff intranet for details.')} className="flex items-center gap-2 px-3 py-2 border rounded-md text-sm bg-white hover:bg-teal-50">
              <Download className="h-4 w-4 text-teal-600" /> Copy Summary Link
            </button>
          </div>
        </header>

        <main className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <aside className="col-span-1">
            <div className="space-y-3">
              {sections.map(s => (
                <motion.button key={s.id} whileHover={{scale:1.02}} whileTap={{scale:0.98}} onClick={()=>setActive(s.id)} className={`w-full text-left p-4 rounded-lg border ${s.color} hover:shadow-md flex items-start gap-3`}>
                  <div className="p-2 rounded-md bg-white/70">{renderIcon(s.icon)}</div>
                  <div>
                    <div className="font-medium">{s.title}</div>
                    <div className="text-xs text-slate-500">Tap to view summary & steps</div>
                  </div>
                </motion.button>
              ))}

              <div className="mt-4 p-4 rounded-lg border bg-slate-50 text-sm">
                <div className="font-semibold">Legend</div>
                <ul className="mt-2 text-xs space-y-1 text-slate-600">
                  <li>• Blue — Hand Hygiene</li>
                  <li>• Green — Cleaning & Disinfection</li>
                  <li>• Amber — Needlestick Safety</li>
                  <li>• Indigo — PPE</li>
                  <li>• Rose — Transmission-Based</li>
                </ul>
              </div>
            </div>
          </aside>

          <section className="col-span-2">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {sections.map(s => (
                <motion.article key={s.id} initial={{opacity:0,y:6}} animate={{opacity: active===s.id?1:0.4, y: active===s.id?0:6}} transition={{duration:0.24}} className={`p-5 rounded-lg border ${s.color} ${active===s.id? 'ring-2 ring-slate-200':''}`} style={{display: active===s.id? 'block':'none'}}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-md bg-white/80">{renderIcon(s.icon)}</div>
                      <h2 className="text-lg font-semibold">{s.title}</h2>
                    </div>
                    <div className="text-xs text-slate-600">Quick summary • ZCMC IPCC</div>
                  </div>

                  <div className="mt-3 text-sm space-y-2">
                    <ul className="list-disc ml-5">
                      {s.bullets.map((b,i)=>(<li key={i}>{b}</li>))}
                    </ul>
                  </div>

                  <div className="mt-4 flex gap-2">
                    <button onClick={()=>alert('Open full procedure / training PDF on intranet (placeholder).')} className="px-3 py-2 border rounded-md text-sm bg-white">View full procedure</button>
                    <button onClick={()=>alert('Start short training quiz (placeholder).')} className="px-3 py-2 border rounded-md text-sm bg-white">Quick quiz</button>
                  </div>
                </motion.article>
              ))}

              <motion.div initial={{opacity:0}} animate={{opacity:1}} className="col-span-1 lg:col-span-2 p-4 rounded-lg border bg-slate-50">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-md font-semibold">Mini Process Flows (Staff Quick-View)</h3>
                    <p className="text-xs text-slate-500">Tap a section on the left to reveal the steps. Use Print/Save PDF for distribution.</p>
                  </div>
                  <div className="text-xs text-slate-600">ZCMC • IPPC</div>
                </div>

                <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="p-3 rounded border bg-white">
                    <div className="text-sm font-medium">Hand Hygiene</div>
                    <ol className="mt-2 text-xs list-decimal ml-5">
                      <li>Before patient contact</li>
                      <li>Wet → Soap → Rub 20–30s → Rinse → Dry</li>
                      <li>Or use ABHR when not visibly soiled</li>
                    </ol>
                  </div>

                  <div className="p-3 rounded border bg-white">
                    <div className="text-sm font-medium">PPE Donning / Doffing</div>
                    <ol className="mt-2 text-xs list-decimal ml-5">
                      <li>Don: Gown → Mask → Goggles → Gloves</li>
                      <li>Doff: Gloves → Goggles → Gown → Mask</li>
                      <li>Hand hygiene between steps</li>
                    </ol>
                  </div>

                  <div className="p-3 rounded border bg-white">
                    <div className="text-sm font-medium">Needlestick</div>
                    <ol className="mt-2 text-xs list-decimal ml-5">
                      <li>Do NOT recap</li>
                      <li>Dispose to sharps container</li>
                      <li>If exposure: Wash → Report → PEP</li>
                    </ol>
                  </div>
                </div>

                <div className="mt-4 text-xs text-slate-600">Prepared by: Infection Prevention & Control Unit (IPCU) — Zamboanga City Medical Center. Aligned with DOH/WHO/CDC guidance; simplified for quick staff reference.</div>
              </motion.div>
            </div>
          </section>
        </main>

        {openModal && (
          <aside className="fixed inset-0 bg-black/40 flex items-center justify-center z-40" onClick={()=>setOpenModal(false)}>
            <motion.div initial={{scale:0.98, opacity:0}} animate={{scale:1, opacity:1}} onClick={(e)=>e.stopPropagation()} className="max-w-2xl w-full p-6 bg-white rounded-lg shadow-lg">
              <div className="flex items-start justify-between">
                <h4 className="text-lg font-semibold">Quick Tips for Staff</h4>
                <button onClick={()=>setOpenModal(false)} className="text-slate-500">Close</button>
              </div>
              <div className="mt-3 text-sm space-y-2">
                <ul className="list-disc ml-5">
                  <li>Keep alcohol-based hand rub (ABHR) available at point-of-care.</li>
                  <li>Use color-coded cleaning cloths—red for high-risk, green for general areas.</li>
                  <li>Sharps containers must be within arm's reach of procedure areas.</li>
                  <li>Practice donning/doffing during every shift until muscle memory forms.</li>
                </ul>
              </div>
              <div className="mt-4 flex justify-end gap-2">
                <button onClick={()=>setOpenModal(false)} className="px-3 py-2 border rounded-md">Close</button>
                <button onClick={()=>{ copyToClipboard("Quick tips: ABHR at point-of-care; color-coded cleaning; sharps at arm's reach; practice donning/doffing.") }} className="px-3 py-2 border rounded-md bg-white">Copy Tips</button>
              </div>
            </motion.div>
          </aside>
        )}

        <footer className="mt-8 text-xs text-slate-500 text-center">Prepared by IPCU • Zamboanga City Medical Center — For staff reference. Last reviewed: {new Date().toLocaleDateString()}</footer>
      </div>
    </div>
  )
}
